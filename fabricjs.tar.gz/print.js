// #1 main buttons
var btnOne = document.getElementById('btnOne');
var btnTwo = document.getElementById('btnTwo');
var btnThree = document.getElementById('btnThree');
var btnSelected = btnOne;

var btnArr = [ btnOne, btnTwo, btnThree ];

for ( var i = 0; i < btnArr.length; i++ ) {
	btnArr[i].onmousedown = function() {
		btnSelected.style.backgroundColor = '';
		this.style.backgroundColor = '#0BB3A5';
		btnSelected = this;
	};
};

// #2 fields for main btn
var fieldForBtnOne = document.getElementById('fieldForBtnOne');
var fieldForBtnTwo = document.getElementById('fieldForBtnTwo');
var fieldForBtnThree = document.getElementById('fieldForBtnThree');

var fieldSelected = fieldForBtnOne;
